class Grade < ApplicationRecord
  has_many :users
end
