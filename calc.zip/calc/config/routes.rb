Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  root 'home#index'

  get '/contacts' => 'home#contacts'

  resources :users

  resources :grades

  resources :worked_times

  resources :reports, only: :index do
    collection do
      post :result
    end
  end
end
