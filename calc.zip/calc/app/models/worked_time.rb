class WorkedTime < ApplicationRecord
  belongs_to :user
end
