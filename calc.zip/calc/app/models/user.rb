class User < ApplicationRecord
  has_many :worked_times
  belongs_to :grade
end
